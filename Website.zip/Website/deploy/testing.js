import { returnTrue } from './testing2.js';

export function testFunc(){
    console.log(returnTrue())
}

document.addEventListener("DOMContentLoaded", function(event) {
    testFunc()
});