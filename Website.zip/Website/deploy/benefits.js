document.addEventListener("DOMContentLoaded", function(event) {
    onPageLoad();
});

function onPageLoad(){
    var claimAmountPage = document.getElementById("claim-amount-container");
    claimAmountPage.style.display = "none";
}

function onPressCalculateBenefitsOwedButton(){
    console.log("Hi")
    if (!checkIfElementsAreFilled(document.getElementById("benefits-form").elements)) return;
    calculateBenefits()    
}

function checkIfElementsAreFilled(formElements){
    let filled = true
    for (let i=0; i < formElements.length; i++){
        var formElement = formElements[i];
        if (formElement.value == "" || formElement.value == null){
            formElement.style.borderColor = "darkred"
            formElement.style.borderWidth = "3px"
            filled = false
        } 
        else {
            formElement.style.borderColor = "black"
            formElement.style.borderWidth = "2px"
        }
    }
    return filled
}

function calculateBenefits(){
    document.getElementById("benefits-form-container").style.display= "none"
    document.getElementById("claim-amount-container").style.display= "grid"
    
    var annualIncome = document.getElementById("benefits-income").value
    var dependents = document.getElementById("benefits-dependents").value

    var totalClaim = (dependents * 100) - (annualIncome / 12);
    if (totalClaim < 0) totalClaim = 0;

    document.getElementById("total-owed").innerHTML = "We've calculated that you can claim up to: " +  returnDollarAmount(totalClaim) + " a month."

}

function returnDollarAmount ( amount){
    return "$" + parseFloat(amount.toPrecision(2))
}

function onScheduleBenefitsMeetingButton(){
    console.log("Would book claim meeting here")
}

function onCancelBenefitsMeetingButton(){
    window.location.href="../html/index.html"
}