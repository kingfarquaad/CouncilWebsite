
document.addEventListener("DOMContentLoaded", function(event) {
    onPageLoad();
});

function onPageLoad(){
    var amountOwedContainer = document.getElementById("amount-owed-container");
    amountOwedContainer.style.display = "none";
}

function onPressFileTaxesButton(){
    if (!checkIfElementsAreFilled(document.getElementById("taxes-identity-form").elements) 
        && !checkIfElementsAreFilled(document.getElementById("taxes-financial-form").elements)) return;
    calculateBenefits()    
}

function checkIfElementsAreFilled(formElements){
    let filled = true
    for (let i=0; i < formElements.length; i++){
        var formElement = formElements[i];
        if (formElement.value == "" || formElement.value == null){
            formElement.style.borderColor = "darkred"
            formElement.style.borderWidth = "3px"
            filled = false
        } 
        else {
            formElement.style.borderColor = "black"
            formElement.style.borderWidth = "2px"
        }
    }
    return filled
}

function onPressFileTaxesButton(){
    document.getElementById("taxes-form-container").style.display= "none"
    document.getElementById("amount-owed-container").style.display= "grid"
    var annualIncome = document.getElementById("tax-income").value
    var dependents = document.getElementById("tax-dependents").value
    var bribesPaid = document.getElementById("tax-bribes-paid").value
    var crimesCommited = document.getElementById("tax-crimes-commited").value

    var annualTax = annualIncome * 0.2
    var dependentsTax = dependents * -100
    var bribesTax = bribesPaid * - 0.2
    var crimesTax = crimesCommited * 1
    var totalTax = annualTax + dependentsTax + bribesTax + crimesTax

    document.getElementById("total-owed").innerHTML = "We've calculated that you owe: " +  returnDollarAmount(totalTax)
    document.getElementById("annual-income-owed").innerHTML = returnDollarAmount(annualTax)
    document.getElementById("dependents-owed").innerHTML = returnDollarAmount(dependentsTax)
    document.getElementById("bribes-paid-owed").innerHTML = returnDollarAmount(bribesTax)
    document.getElementById("crimes-commited-owed").innerHTML = returnDollarAmount(crimesTax)
}

function returnDollarAmount ( amount){
    return "$" + parseFloat(amount.toPrecision(2))
}