let currentUserPopup = null

class LoginPopup extends HTMLElement{
    connectedCallback() {
        this.innerHTML = `
        <div>
        <div class="popup-container" id="loginPopupContainer">
            <div class="login-popup" id="loginPopup">
                <h2 style="text-align: center;">Login</h2>
                <form class="input-grid" id="login-form">
                    <div class="input-label">Email</div>
                    <input class="text-input-field" type="email" id="login-email" />
                    <div class="input-label">Password</div>
                    <input class="text-input-field" type="password" id="login-password" />
                </form>
                <div id="login-error-message" style="text-align: center; color: darkred "> </div>
                <div class="buttons-container">
                    <button class="medium-button" onclick="hideCurrentUserPopup()">Close</button>
                    <button class="medium-button" onclick="onShowCreateNewUserPopupButton()">Create New User</button>
                    <button class="medium-button" onclick="onLogInPressed()">Login</button>
                </div>
            </div>
        </div>
    </div>
    <div>
        <div class="popup-container" id="createNewUserPopupContainer">
            <div class="login-popup" id="createNewUserPopup">
                <h2 style="text-align: center;">Create New User</h2>
                <form class="input-grid" id="new-user-form">
                    <div class="input-label">First Name</div>
                    <input class="text-input-field" type="text" id="new-fname" />
                    <div class="input-label">Last Name</div>
                    <input class="text-input-field" type="text" id="new-lname" />
                    <div class="input-label">Email</div>
                    <input class="text-input-field" type="email" id="new-email" />
                    <div class="input-label">Password</div>
                    <input class="text-input-field" type="password" id="new-password" />
                </form>
                <div id="create-new-user-error-message" style="text-align: center; color: darkred;"> </div>
                <div class="buttons-container">
                    <button class="medium-button" onclick="hideCurrentUserPopup()">Close</button>
                    <button class="medium-button" onclick="onClickUserButton()">Log In</button>
                    <button class="medium-button" onclick="onTryCreateNewUserPressed()">Create New User</button>
                </div>
            </div>
        </div>
        `        
    }
}


customElements.define("login-popup", LoginPopup)

let users = [];
let userLoggedIn = false;

createNewUser("a", "a")

function isUserLoggedIn(){
    return userLoggedIn;
}

function hideCurrentUserPopup(){
    if (currentUserPopup == null) return;
    currentUserPopup.style = "none";
}

function onClickUserButton() {
    hideCurrentUserPopup();
    currentUserPopup = document.getElementById("loginPopupContainer");
    currentUserPopup.style.display = "flex"
}

function onShowCreateNewUserPopupButton(){
    showErrorMessageOnCurrentPopup("");
    hideCurrentUserPopup();
    
    currentUserPopup = document.getElementById("createNewUserPopupContainer");
    currentUserPopup.style.display = "flex"
}

function showErrorMessageOnCurrentPopup(errorMessage){
    if (currentUserPopup == null) return;
    document.getElementById("login-error-message").innerHTML = errorMessage;
    document.getElementById("create-new-user-error-message").innerHTML = errorMessage;
}

function onLogInPressed(){
    showErrorMessageOnCurrentPopup("");
    var formElements = document.getElementById("login-form").elements;
    var username;
    var password;
    for (let i = 0; i < formElements.length; i++){
        var formElement = formElements[i];
        if (formElement.value == "") 
        {
            if (formElement.id == "login-email") showErrorMessageOnCurrentPopup("Please enter an email address");
            else if (formElement.id == "login-password") showErrorMessageOnCurrentPopup("Please enter a password");
            return;
        }
        if (formElement.id == "login-email") username = formElement.value;
        else if (formElement.id == "login-password") password = formElement.value;
    }

    if (!usernameExists(username)) 
    {
        showErrorMessageOnCurrentPopup("Username not found");
        return;
    }
    var correctPassword = getPasswordByUsername(username);
    if (correctPassword != password){
        showErrorMessageOnCurrentPopup("Incorrect password");
        return;
    }
    hideCurrentUserPopup();
    // logIn();
}


// function logIn(){
//     hideCurrentUserPopup();
//     setUserButtonText("User")
// }


function createNewUser(username, password) {
    users.push({ username, password });
}

function findUserByUsername(username) {
    return users.find(user => user.username === username);
}

function getPasswordByUsername(username) {
    const user = findUserByUsername(username);
    return user ? user.password : null;
}

function usernameExists(username) {
    return users.some(user => user.username === username);
}

module.exports = {
    isUserLoggedIn
};


// function onTryCreateNewUserPressed(){
//     var formElements = document.getElementById("new-user-form").elements;
//     var fname;
//     var lname;
//     var email;
//     var password
//     for (let i = 0; i < formElements.length; i++){
//         var formElement = formElements[i];
//         if (formElement.value == "") 
//         {
//             if (formElement.id == "new-fname") showErrorMessageOnCurrentPopup("Please enter a first name");
//             else if (formElement.id == "new-lname") showErrorMessageOnCurrentPopup("Please enter a last name");
//             else if (formElement.id == "new-email") showErrorMessageOnCurrentPopup("Please enter an email");
//             else if (formElement.id == "new-password") showErrorMessageOnCurrentPopup("Please enter a password");
//             return;
//         }
//         if (formElement.id == "fname") fname = formElement.value;
//         else if (formElement.id == "lname") lname = formElement.value;
//         else if (formElement.id == "email") email = formElement.value;
//         else if (formElement.id == "password") password = formElement.value;
//     }
//     console.log("User created: " + fname + " " + lname)

//     createNewUser();
// }