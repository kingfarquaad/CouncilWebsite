document.addEventListener("DOMContentLoaded", function(event) {
    onPageLoad();
});

function onPageLoad(){
    var servicesAndRefuseContainer = document.getElementById("services-and-refuse-text-container");
    servicesAndRefuseContainer.style.display = "none";
}

function onNeighbourhoodSelect(){
    var neighbourhoodInput = document.getElementById("neighborhood-input").value;
    var acceptedNeighbourhoods = Array.from(document.getElementById("regions").children); 
    var inputInAcceptedNeighbourhoods = false;
    for(let i = 0; i < acceptedNeighbourhoods.length; i++){
        // console.log(acceptedNeighbourhoods[i].value) ;
        // console.log(neighbourhoodInput) ;
        if (acceptedNeighbourhoods[i].value == neighbourhoodInput) inputInAcceptedNeighbourhoods=true;
    }
    if (!inputInAcceptedNeighbourhoods) return;
    
    
    var servicesAndRefuseContainer = document.getElementById("services-and-refuse-text-container").style.display="grid";

    var refuseDayText = document.getElementById("refuse-day-text").innerHTML = "Wednesday"
    var nightSoilText = document.getElementById("night-soil-text").innerHTML = "Wednesday"
}
