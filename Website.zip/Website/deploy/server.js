// server.js

const express = require('express');
const bodyParser = require('body-parser');
const userModel = require('./userModel');

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Endpoint to register a new user
app.post('/register', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
    }

    if (userModel.usernameExists(username)) {
        return res.status(400).json({ message: 'Username already exists' });
    }

    userModel.addUser(username, password);
    res.status(201).json({ message: 'User registered successfully' });
});

// Endpoint to login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const storedPassword = userModel.getPasswordByUsername(username);

    if (!storedPassword || storedPassword !== password) {
        return res.status(401).json({ message: 'Invalid username or password' });
    }

    res.status(200).json({ message: 'Login successful' });
});

// Endpoint to get user information
app.get('/user/:username', (req, res) => {
    const username = req.params.username;
    const user = userModel.findUserByUsername(username);

    if (!user) {
        return res.status(404).json({ message: 'User not found' });
    }

    res.status(200).json(user);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});