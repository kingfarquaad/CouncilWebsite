class StickyHeader extends HTMLElement{
    connectedCallback() {
        this.innerHTML = `
        <nav class="navbar">
            <div class="navbar-container">
                <a href="../html/index.html" id="navbar-logo;"> <img src="../images/logo.png" alt="" style="height: 90%;"></a>
                <span></span>
                <div class="login-button" onclick="onClickUserButton()"><img src="../images/user.png" alt="" style="height: 90%;"></div>
            </div>
        </nav>         
        `        
    }
}

customElements.define("sticky-header", StickyHeader)