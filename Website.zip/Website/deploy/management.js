import { isUserLoggedIn } from './userMng.js';

document.addEventListener("DOMContentLoaded", function(event) {
    onPageLoad();
});

function onPageLoad(){
    if (!isUserLoggedIn) console.log("not logged in")
}